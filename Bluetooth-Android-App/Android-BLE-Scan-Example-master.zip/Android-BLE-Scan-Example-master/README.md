# Android-BLE-Scan-Example
This is a simple example app that turns on ble and scans for devices, listing them out. It's for Android (M) API 23

Built in Android Studio with gradle system. The app scans for nearby BLE devices and displays them in a TextView. 
